#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
terminal_voz.py — Terminal de Linux controlada por voz.

Dictás comandos por voz, se ejecutan en una sesión de shell PERSISTENTE
(se mantienen cd, variables de entorno y demás entre comandos), se muestra
la salida y opcionalmente se lee en voz alta.

Seguridad: los comandos peligrosos piden confirmación explícita antes de
ejecutarse, porque el reconocimiento de voz se equivoca.

Uso básico:
    python3 terminal_voz.py

Controles por voz (palabras reservadas):
    "salir"        -> cierra la app
    "cancelar"     -> descarta lo dictado
    "repetir"      -> vuelve a leer la última salida
    "modo texto"   -> pasa a escribir el comando con el teclado

Tecla ENTER (sin hablar) = escribir el comando a mano (fallback).
"""

import os
import re
import sys

# ----- Dependencias obligatorias -----
try:
    import pexpect
except ImportError:
    sys.exit("Falta 'pexpect'.  Instalá con:  pip install pexpect")

try:
    import speech_recognition as sr
except ImportError:
    sys.exit("Falta 'SpeechRecognition'.  Instalá con:  pip install SpeechRecognition")

# ----- Dependencia opcional (lectura en voz alta) -----
try:
    import pyttsx3
    TTS_OK = True
except ImportError:
    TTS_OK = False


# Prompt único para detectar cuándo termina cada comando en el shell.
PROMPT = "VOZ_TERM_9X7Q> "

# ---------------------------------------------------------------------------
# ALIAS DE VOZ  ->  COMANDO REAL
# Dictar sintaxis cruda ("ele ese guion ele a") es frustrante. Mejor mapear
# frases naturales a comandos. Editá / agregá los tuyos libremente.
# ---------------------------------------------------------------------------
ALIAS = {
    "listar": "ls -la",
    "listar archivos": "ls -la",
    "donde estoy": "pwd",
    "subir un nivel": "cd ..",
    "ir a inicio": "cd ~",
    "limpiar": "clear",
    "fecha": "date",
    "quien soy": "whoami",
    "procesos": "ps aux",
    "espacio en disco": "df -h",
    "memoria": "free -h",
    "red": "ip a",
}

# ---------------------------------------------------------------------------
# PATRONES PELIGROSOS  ->  exigen confirmación antes de ejecutar.
# ---------------------------------------------------------------------------
PATRONES_PELIGROSOS = [
    r"\brm\s+-[a-z]*r[a-z]*f", r"\brm\s+-[a-z]*f[a-z]*r",
    r"\bmkfs\b", r"\bdd\b", r"\bshred\b",
    r">\s*/dev/sd", r"\bof=/dev/",
    r":\(\)\s*\{",                          # fork bomb
    r"\bchmod\s+-R\b", r"\bchown\s+-R\b",
    r"\bshutdown\b", r"\breboot\b", r"\bhalt\b", r"\bpoweroff\b",
    r"\bfdisk\b", r"\bparted\b", r"\bmkswap\b",
    r"--no-preserve-root",
    r"\buserdel\b", r"\bgroupdel\b",
    r"\b(curl|wget)\b.*\|\s*(sudo\s+)?(ba)?sh",   # curl ... | sh
]


def es_peligroso(comando: str) -> bool:
    return any(re.search(p, comando) for p in PATRONES_PELIGROSOS)


class TerminalVoz:
    def __init__(self, idioma="es-AR", leer_salida=True):
        self.idioma = idioma
        self.leer_salida = leer_salida and TTS_OK
        self.ultima_salida = ""

        # --- Motor de voz (TTS) ---
        self.tts = None
        if self.leer_salida:
            try:
                self.tts = pyttsx3.init()
                self.tts.setProperty("rate", 175)
            except Exception:
                self.leer_salida = False

        # --- Reconocedor de voz ---
        self.rec = sr.Recognizer()
        self.mic = sr.Microphone()
        print("Calibrando ruido ambiente (1 s)... quedate en silencio.")
        with self.mic as fuente:
            self.rec.adjust_for_ambient_noise(fuente, duration=1)

        # --- Shell persistente ---
        self.shell = pexpect.spawn("/bin/bash", encoding="utf-8",
                                   echo=False, timeout=30)
        # Prompt fijo y sin colores, para poder detectar el fin de cada comando.
        self.shell.sendline(f'export PS1="{PROMPT}"; export PS2=""')
        self.shell.expect_exact(PROMPT)

    # -------------------- Voz --------------------
    def hablar(self, texto: str):
        if self.leer_salida and self.tts:
            self.tts.say(texto)
            self.tts.runAndWait()

    def escuchar(self) -> str:
        """Devuelve el texto reconocido, o "" si no entendió / hubo error."""
        try:
            with self.mic as fuente:
                print("\n🎤 Escuchando... (hablá ahora)")
                audio = self.rec.listen(fuente, timeout=8, phrase_time_limit=15)
        except sr.WaitTimeoutError:
            print("(no escuché nada)")
            return ""
        try:
            texto = self.rec.recognize_google(audio, language=self.idioma)
            print(f"📝 Entendí: «{texto}»")
            return texto.strip()
        except sr.UnknownValueError:
            print("(no entendí lo que dijiste)")
            return ""
        except sr.RequestError as e:
            print(f"(error del servicio de reconocimiento: {e})")
            return ""

    # -------------------- Traducción frase -> comando --------------------
    def a_comando(self, frase: str) -> str:
        f = frase.lower().strip()
        if f in ALIAS:
            return ALIAS[f]
        # Si no hay alias, se usa la frase tal cual como comando literal.
        return frase.strip()

    # -------------------- Ejecución --------------------
    def ejecutar(self, comando: str):
        try:
            self.shell.sendline(comando)
            self.shell.expect_exact(PROMPT)
        except pexpect.TIMEOUT:
            print("⏱  El comando tardó demasiado (timeout).")
            return
        except pexpect.EOF:
            print("El shell se cerró.")
            sys.exit(0)

        salida = self.shell.before
        # Quita la línea del comando que el shell suele devolver primero.
        lineas = salida.splitlines()
        if lineas and lineas[0].strip() == comando.strip():
            lineas = lineas[1:]
        salida = "\n".join(lineas).strip()

        self.ultima_salida = salida
        if salida:
            print("─" * 50)
            print(salida)
            print("─" * 50)
            # Lee sólo las primeras líneas para no eternizarse.
            self.hablar(" ".join(salida.splitlines()[:5]) or "Listo.")
        else:
            print("(sin salida)")
            self.hablar("Listo.")

    # -------------------- Bucle principal --------------------
    def loop(self):
        print("\n=== Terminal por voz lista ===")
        print("ENTER para escuchar  |  escribí un comando para mandarlo a mano")
        print("Decí 'salir' para terminar.\n")
        while True:
            try:
                entrada = input("⏎ ENTER para hablar  >  ")
            except (EOFError, KeyboardInterrupt):
                print("\nChau!")
                break

            # Si escribió algo, se ejecuta directo (fallback de teclado).
            if entrada.strip():
                self._procesar(entrada.strip())
                continue

            # Si no, se escucha por voz.
            frase = self.escuchar()
            if not frase:
                continue
            self._procesar(frase)

    def _procesar(self, frase: str):
        baja = frase.lower().strip(" .")

        if baja in ("salir", "cerrar", "terminar"):
            print("Cerrando. ¡Chau!")
            self.hablar("Cerrando.")
            sys.exit(0)
        if baja in ("cancelar", "cancela"):
            print("Cancelado.")
            return
        if baja in ("repetir", "repetí", "repeti"):
            if self.ultima_salida:
                print(self.ultima_salida)
                self.hablar(" ".join(self.ultima_salida.splitlines()[:5]))
            return
        if baja in ("modo texto", "teclado"):
            cmd = input("Escribí el comando: ").strip()
            if cmd:
                self._confirmar_y_ejecutar(cmd)
            return

        comando = self.a_comando(frase)
        self._confirmar_y_ejecutar(comando)

    def _confirmar_y_ejecutar(self, comando: str):
        print(f"⚙  Comando: {comando}")
        if es_peligroso(comando):
            print("⚠️  COMANDO PELIGROSO detectado.")
            self.hablar("Atención, comando peligroso. Confirmá.")
            resp = input("   Escribí 'si' para ejecutar: ").strip().lower()
            if resp not in ("si", "sí", "s", "yes", "y"):
                print("   Abortado.")
                return
        self.ejecutar(comando)


def main():
    # Tip: cambiá el idioma a "en-US" si vas a dictar comandos en inglés.
    app = TerminalVoz(idioma="es-AR", leer_salida=True)
    if not TTS_OK:
        print("(Nota: pyttsx3 no está instalado; no habrá lectura en voz alta.)")
    app.loop()


if __name__ == "__main__":
    main()
